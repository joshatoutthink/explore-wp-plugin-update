import './scripts/main.js'
import './styles/main.scss'
